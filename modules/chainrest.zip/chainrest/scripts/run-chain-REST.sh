#!/bin/bash
docker-compose -f ../docker-compose-REST.yml up -d